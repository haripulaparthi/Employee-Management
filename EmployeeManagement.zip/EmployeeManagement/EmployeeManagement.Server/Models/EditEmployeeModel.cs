﻿using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Server.Models
{
    public class EditEmployeeModel
    {
        public int EmployeeId { get; set; }
        [Required(ErrorMessage = "FirstName is mandatory")]
        [MinLength(2)]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "LastName is mandatory")]
        public string LastName { get; set; }
        [EmailDomainValidator(AllowedDomain = "gmail.com")]
        public string Email { get; set; }
        public string ConfirmEmail { get; set; }
        public DateTime DateOfBrith { get; set; }
        public Gender Gender { get; set; }
        public int? DepartmentId { get; set; }
        public string PhotoPath { get; set; }
        //public Department Department { get; set; } = new Department();
    }

    public class EmailDomainValidator : ValidationAttribute
    {
        public string AllowedDomain { get; set; }

        protected override ValidationResult IsValid(object value,
            ValidationContext validationContext)
        {
            if (string.IsNullOrEmpty(Convert.ToString(value)))
            {
                return new ValidationResult($"Email is required",
            new[] { validationContext.MemberName });
            }
            else
            {
                string[] strings = value.ToString().Split('@');
                if (strings[1].ToUpper() == AllowedDomain.ToUpper())
                {
                    return null;
                }
                return new ValidationResult($"Domain must be {AllowedDomain}",
            new[] { validationContext.MemberName });
            }
        }
    }
}
